import pygame
import random
import sys
import time
import math

    # Initialize pygame
pygame.init()

SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
FPS = 60

    # Colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
YELLOW = (255, 255, 0)

    # Text font
font = pygame.font.Font("GethoBold-v0wD.ttf", 36)
text_font = pygame.font.SysFont(None, 36)

    # Title Font
title_font = pygame.font.SysFont(None, 72)

    # Title
title_text = "Dino Dig Adventures!"
title_surface = title_font.render(title_text, True, WHITE)
title_rect = title_surface.get_rect(center=(SCREEN_WIDTH // 2,
                                            SCREEN_HEIGHT // 4))

    # Set the window title
pygame.display.set_caption("Lost Relic Edition")

    # Screen dimensions
width, height = SCREEN_WIDTH, SCREEN_HEIGHT
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))

    # Game variables
high_score = 0
score = 0
level = 1
lives = 6
invun = 0

    # Set initial position of the background and player character
background_x = 0
background_y = 0
x_pos = width/2
y_pos = height/2
player_x = x_pos
player_y = y_pos

scroll_speed = 2 # Set the speed of scrolling

game_active = False  # Indicates if the game is active or in menu mode

random_seed = random.randint(0, 1000000)


    # Sets up character and background sprites
game_background = pygame.image.load('brickbackground.jpg').convert_alpha()

sprite_image = pygame.image.load('cavamen.png').convert_alpha()
big_sprite_image = pygame.transform.scale(sprite_image, (80,80))
sprite_rect = big_sprite_image.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2))

dino_image = pygame.image.load('dinosprite.png').convert_alpha()
dino_image_small = pygame.transform.scale(dino_image, (100, 100))

tail_image = pygame.image.load('Tail.png').convert_alpha()
tail_image_transform = pygame.transform.scale(tail_image, (200, 200))

head_image = pygame.image.load('Fossil.png').convert_alpha()
head_image_transform = pygame.transform.scale(head_image, (200, 200))

legs_image = pygame.image.load('Legs.png').convert_alpha()
legs_image_transform = pygame.transform.scale(legs_image, (200, 200))

ribcage_image = pygame.image.load('RibCage.png').convert_alpha()
ribcage_image_transform = pygame.transform.scale(ribcage_image, (200, 200))

arms_image = pygame.image.load('Arms.png').convert_alpha()
arms_image_transform = pygame.transform.scale(arms_image, (200, 200))

fossil_image = pygame.image.load('Fossil.png').convert_alpha()
fossil_image_small = pygame.transform.scale(fossil_image, (40, 40))

enemy_list = []
fossil_list = []
fossil_spawn = ['top', 'bottom', 'left', 'right']
available_fossil = 0

    #Game Over text
game_over_text = "GAME OVER"
game_over_surface = font.render(game_over_text, True, WHITE)
game_over_rect = game_over_surface.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2))

    #Level up text
level_up_text = "You uncovered a mysterious fossil!"
level_up_surface = font.render(level_up_text, True, WHITE)
level_up_rect = level_up_surface.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2))

    # Frame rate
clock = pygame.time.Clock()

    # Button class for menu
class Button:

  def __init__(self, color, x, y, width, height, text=''):
    self.color = color
    self.x = x
    self.y = y
    self.width = width
    self.height = height
    self.text = text

  def draw(self, win, outline=None):
    if outline:
      pygame.draw.rect(
          win, outline,
          (self.x - 2, self.y - 2, self.width + 4, self.height + 4), 0)
    pygame.draw.rect(win, self.color,
                     (self.x, self.y, self.width, self.height), 0)
    if self.text != '':
      text = text_font.render(self.text, 1, WHITE)
      win.blit(text,
               (self.x + (self.width / 2 - text.get_width() / 2), self.y +
                (self.height / 2 - text.get_height() / 2)))

  def isOver(self, pos):
    if self.x < pos[0] < self.x + self.width and self.y < pos[
        1] < self.y + self.height:
      return True
    return False

game_paused = False

start_button_img = pygame.image.load('start_btn.png')
exit_button_img = pygame.image.load('exit_btn.png')

    # Scale the buttons to desired dimensions
button_width = 200
button_height = 50
start_button_img = pygame.transform.scale(start_button_img, (button_width, button_height))
exit_button_img = pygame.transform.scale(exit_button_img, (button_width, button_height))

    # Resets game if player lost
def reset_game():
    global score, lives, level, obstacles, game_active, invun, music_enabled, enemy_list, fossil_list
    score = 0
    lives = 5
    level = 1
    enemy_list = []
    fossil_list = []
    game_active = True
    invun = 0

    # Progresses through level
def level_up():
    global level, score, lives, game_active, invun, enemy_list, fossil_list, running, available_fossil
    global level_up_text, level_up_rect, level_up_surface

    running = True

    # Get the current time when the game over screen starts
    start_time = pygame.time.get_ticks()

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                pygame.quit()
                sys.exit()

        elapsed_time = pygame.time.get_ticks() - start_time

        screen.fill(BLACK)

        level_rect = game_background.get_rect(center=(SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2))
        screen.blit(level_up_surface, level_up_rect)

            # IF statements that shows the treasures of the game 
        if level == 1:
            screen.blit(head_image_transform, ((SCREEN_WIDTH/2)-120,(SCREEN_HEIGHT/2)+30))
        elif level == 2:
            screen.blit(arms_image_transform, ((SCREEN_WIDTH/2)-120,(SCREEN_HEIGHT/2)+30))
        elif level == 3:
            screen.blit(ribcage_image_transform, ((SCREEN_WIDTH/2)-120,(SCREEN_HEIGHT/2)+30))
        elif level == 4:
            screen.blit(legs_image_transform, ((SCREEN_WIDTH/2)-120,(SCREEN_HEIGHT/2)+30))
        elif level == 5:
            screen.blit(tail_image_transform, ((SCREEN_WIDTH/2)-120,(SCREEN_HEIGHT/2)+30))
        elif level >= 6:
            level_up_text = "You discovered all 5 bone structures!"
            level_up_rect = level_up_surface.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2))
            screen.blit(level_up_surface, level_up_rect)
            if elapsed_time >= 3000:

                running = False
                main_menu()
            

            # Update the display
        pygame.display.flip()

            # Cap the frame rate
        clock.tick(FPS)

        if elapsed_time >= 3000:
            level_rect = game_background.get_rect(center=(SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2))
            screen.blit(level_up_surface, level_up_rect)
            level +=1
            enemy_list = []
            fossil_list = []
            fossil_spawn = ['top', 'bottom', 'left', 'right']
            available_fossil = 0
            lives = 6 - math.ceil(level/2) 
            invun = 0
            main()

def main_menu():
    global game_active, background_x

        # Set running to True
    running = True
    sprite_rect = game_background.get_rect(center=(SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2))

        # Get the current time when the game over screen starts
    start_time = pygame.time.get_ticks()

        # Update the display
    pygame.display.update()

    start_button_rect = pygame.Rect(150, 300, button_width, button_height)
    exit_button_rect = pygame.Rect(450, 300, button_width, button_height)

        # Sizes for font
    max_size = 75
    min_size = 60

        # Functioning main menu that starts or closes game
        # on clicked button
    while running:
        for event in pygame.event.get():
                # If close window is clicked, close game
            if event.type == pygame.QUIT:
                running = False
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if start_button_rect.collidepoint(event.pos):  # Play game if play button is clicked
                    print("Start button clicked!")
                    reset_game()
                    game_active = True
                    running = False
                elif exit_button_rect.collidepoint(event.pos):  # Close game if close button is clicked
                    print("Exit button clicked!")
                    running = False
                    pygame.quit()
                    sys.exit()

            # Sets up main menu text and font
        font_size = min_size + (max_size - min_size) * abs(pygame.time.get_ticks() % 2000 - 1000) / 1000
        title_font = pygame.font.Font("GethoBold-v0wD.ttf", int(font_size))
        title_surface = title_font.render(title_text, True, WHITE)
        title_rect = title_surface.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 4))         

            # Draws main menu background
        screen.fill(BLACK)
        screen.blit(game_background, sprite_rect)
        screen.blit(title_surface, title_rect)

        # Draw buttons
        screen.blit(start_button_img, (150, 300))
        screen.blit(exit_button_img, (450, 300))

            # Draws pulsating title
        screen.blit(title_surface, title_rect)

        pygame.display.flip() # Updates display

    # Defines game over sequences
def game_over():
    global game_active, score, high_score, game_paused
    game_active = False
    high_score = max(score, high_score)
    game_Over_Screen()

    # Sets up game over screen 
def game_Over_Screen():
    global running

        # Set running to True
    running = True

        # Get the current time when the game over screen starts
    start_time = pygame.time.get_ticks()

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                pygame.quit()
                sys.exit()

            # Calculate the elapsed time since the game over screen started
        elapsed_time = pygame.time.get_ticks() - start_time

            # Draw background and text
        screen.fill(RED)
        screen.blit(game_over_surface, game_over_rect)

            # Update the display
        pygame.display.flip()

            # Cap the frame rate
        clock.tick(FPS)

            # Introduce a short delay before going back to main menu"
        if elapsed_time >= 3000:
            running = False
            main_menu()

    # Displays game and high score
def display_score_and_high_score():
    global score, high_score

    score_text = text_font.render(f"Score: {score}", True, WHITE)
    high_score_text = text_font.render(f"High Score: {high_score}", True, WHITE)
    level_text = text_font.render(f"Level: {level}", True, WHITE)
    screen.blit(score_text, (width - score_text.get_width() - 10, 10))
    screen.blit(high_score_text, (width - high_score_text.get_width() - 10,
                                50))  
    screen.blit(level_text, (width - level_text.get_width() - 10, 90))


    # Main game loop
def main():
    global lives, score, game_active, sound_effects_enabled, music_enabled, game_paused
    global level, background_x, background_y, available_fossil

    while game_active:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        if not game_paused:  # Wanted to implement pause feature; however, was unable to due to time
            background_rect = game_background.get_rect(center=(SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2))  
            screen.blit(game_background, background_rect)
            screen.fill((0, 0, 0))

                # Moves background according to WASD input
                # to emulate a scrolling background
            keys = pygame.key.get_pressed()
            if keys[pygame.K_a]:  # Move left when 'a' key is pressed
                background_x += scroll_speed
            if keys[pygame.K_d]:  # Move right when 'd' key is pressed
                background_x -= scroll_speed
            if keys[pygame.K_w]:  # Move left when 'a' key is pressed
                background_y += scroll_speed
            if keys[pygame.K_s]:  # Move right when 'd' key is pressed
                background_y -= scroll_speed

                # If the background goes off-screen, 
                # reset its position to start scrolling again
            if background_x <= -game_background.get_width():
                background_x = 0
            if background_x > game_background.get_width():
                background_x = 0
            if background_y <= -game_background.get_height():
                background_y = 0
            if background_x > game_background.get_height():
                background_y = 0

                # Emulates a grid of background images
                # that enables a smooth scroll with movement
            screen.blit(game_background, (background_x - game_background.get_width(), background_y - game_background.get_height()))
            screen.blit(game_background, (background_x - game_background.get_width(), background_y))
            screen.blit(game_background, (background_x - game_background.get_width(), background_y + game_background.get_height()))

            screen.blit(game_background, (background_x, background_y - game_background.get_height()))
            screen.blit(game_background, (background_x, background_y))
            screen.blit(game_background, (background_x, background_y + game_background.get_height()))

            screen.blit(game_background, (background_x + game_background.get_width(), background_y - game_background.get_height()))
            screen.blit(game_background, (background_x + game_background.get_width(), background_y))
            screen.blit(game_background, (background_x + game_background.get_width(), background_y + game_background.get_height()))

                # Spawn enemies along the edges of the screen
            if (len(enemy_list) < 3 * level):
                if random.random() < 0.01:  # Adjust spawn rate as desired
                    side = random.choice(['top', 'bottom', 'left', 'right'])
                    if side == 'top':
                        enemy_rect = dino_image_small.get_rect(midbottom=(random.randint(0, SCREEN_WIDTH), 0))
                    elif side == 'bottom':
                        enemy_rect = dino_image_small.get_rect(midtop=(random.randint(0, SCREEN_WIDTH), SCREEN_HEIGHT))
                    elif side == 'left':
                        enemy_rect = dino_image_small.get_rect(midright=(0, random.randint(0, SCREEN_HEIGHT)))
                    elif side == 'right':
                        enemy_rect = dino_image_small.get_rect(midleft=(SCREEN_WIDTH, random.randint(0, SCREEN_HEIGHT)))
                    enemy_list.append(enemy_rect)

                # Updates enemy trajectory to follow the movement
                # of the player
            for enemy_rect in enemy_list:
                dx = player_x - enemy_rect.x + (big_sprite_image.get_width() - enemy_rect.width) / 2
                dy = player_y - enemy_rect.y + (big_sprite_image.get_height() - enemy_rect.height) / 2
                distance = max(abs(dx), abs(dy))
                if distance == 0:
                    distance +=1
                dx = dx / distance * 1.7
                dy = dy / distance * 1.7
                enemy_rect.x += dx
                enemy_rect.y += dy

                # Displays enemies onto screen plane
            for enemy_rect in enemy_list:
                screen.blit(dino_image_small, enemy_rect)

                # Spawns fossils on level
            if (available_fossil<level):
                if random.random() < 0.006:  # Adjust spawn rate

                        # Choose a random element from the array
                        # that determines which direction the fossil will spawn
                    chosen_spawn = random.choice(fossil_spawn)
                    if chosen_spawn == 'top':
                        available_fossil+=1
                        print("A fossil has been spotted above!")
                        fossil_rect = fossil_image_small.get_rect(midbottom=(random.randint(0, SCREEN_WIDTH), 0))
                    elif chosen_spawn == 'bottom':
                        available_fossil+=1
                        print("A fossil has been spotted below!")
                        fossil_rect = fossil_image_small.get_rect(midtop=(random.randint(0, SCREEN_WIDTH), SCREEN_HEIGHT))
                    elif chosen_spawn == 'left':
                        available_fossil+=1
                        print("A fossil has been spotted left!")
                        fossil_rect = fossil_image_small.get_rect(midright=(0, random.randint(0, SCREEN_HEIGHT)))
                    elif chosen_spawn == 'right':
                        available_fossil+=1
                        print("A fossil has been spotted right!")
                        fossil_rect = fossil_image_small.get_rect(midleft=(SCREEN_WIDTH, random.randint(0, SCREEN_HEIGHT)))
                    fossil_list.append(fossil_rect)

                # Updates fossil location
                # to travel in direction of the player
            for fossil_rect in fossil_list:
                keys = pygame.key.get_pressed()
                if keys[pygame.K_a]:
                    fossil_rect.x += 2
                if keys[pygame.K_d]: 
                    fossil_rect.x -= 2
                if keys[pygame.K_w]:
                    fossil_rect.y += 2
                if keys[pygame.K_s]: 
                    fossil_rect.y -= 2

                # Displays fossils on screen
            for fossil_rect in fossil_list:
                screen.blit(fossil_image_small, fossil_rect)
                
                # Function call that displays and
                # manipulates player sprite 
            draw_player(x_pos, y_pos)
            display_score_and_high_score()
            display_lives()

                # Check for game over condition
            if lives <= 0:
                game_over()

            pygame.display.flip()

            clock.tick(FPS * (1 + level * 0.1))


def draw_player(x_pos,y_pos):
    global lives, invun, score, player_x, player_y, background_x, background_y, level

    player_image_left = pygame.transform.flip(big_sprite_image, True, False)
    player_image_right = big_sprite_image

#        Initialize player direction
    player_direction = 'right' 

    keys = pygame.key.get_pressed()
    if keys[pygame.K_a]:  # Move left when 'a' key is pressed
        player_x -= 5 
        player_direction = 'left'
    if keys[pygame.K_d]:  # Move right when 'd' key is pressed
        player_x += 5
        player_direction = 'right'
    if keys[pygame.K_w]:  # Move up when 'w' key is pressed
        player_y -= 5 
    if keys[pygame.K_s]:  # Move down when 's' key is pressed
        player_y += 5

        # Resets player sprite position back to zero
        # once at end of screen
    player_x = player_x % (SCREEN_WIDTH-70)
    player_y = player_y % (SCREEN_HEIGHT-70)

    player_center = (player_x + 45, player_y + 55)
    player_radius = 35  # The radius of the player's circular hitbox

        # Sets up player sprite hitbox and behavior when hit
    global player_rect
    player_rect = pygame.Rect(player_center[0]-30,player_center[1]-50, 50, 70)
    if invun > 0:
        if invun % 60 < 10:
            pygame.draw.rect(screen, RED, (player_x+12, player_y, 50,80),3)
        else:
            pygame.draw.rect(screen, BLACK, (player_x+12, player_y, 50,80), 3)
        invun -= 1
        for goal in fossil_list:
            goal_center = (goal[0]+2, goal[1]+2)
            goal_radius = 6  
            goal_rect = pygame.Rect(goal_center[0], goal_center[1], 45,45)

                # Determines when player sprite touches fossil treasure
            if player_rect.colliderect(goal_rect):
                score += 2
                if (score - (level * 1000)) > 0:
                    level_up()
    else:
        if check_collision(player_center, player_radius) == 0:
            lives -= 1
            if lives > 0:
                invun = 240
            else:
                game_over()
        elif check_collision(player_center, player_radius) == 1:
            score += 5
            if (score - (level * 1000)) > 0:
                    level_up()


        # Display left facing player sprite 
    if player_direction == 'left':
        screen.blit(player_image_left, (player_x, player_y))
    else:
        screen.blit(player_image_right, (player_x, player_y))

    # Function to check collisions between the player sprite and enemies,
    # and player sprite and fossils
def check_collision(player_center, player_radius):
    global player_rect, number, invun
    for ob in enemy_list:
        ob_center = (ob[0] + 10, ob[1] + 40)
        ob_radius = 6  # Half of the width of the obstacle
        ob_rect = pygame.Rect(ob_center[0], ob_center[1], 70,55)
        if player_rect.colliderect(ob_rect):
            return 0

    for goal in fossil_list:
        goal_center = (goal[0]+2, goal[1]+2)
        goal_radius = 6  # Half of the width of the obstacle
        goal_rect = pygame.Rect(goal_center[0], goal_center[1], 45,45)
        if player_rect.colliderect(goal_rect):
            return 1

    # Displays player lives in top left corner
def display_lives():
  small_sprite = pygame.transform.scale(sprite_image, (32, 32))
  for i in range(lives):
    screen.blit(small_sprite,
                (10 + i * (small_sprite.get_width() + 5), 10))


# Start the game from the main menu
main_menu()

# Run the main game loop
while True:
    if game_active:
        main()
    else:
        main_menu()
